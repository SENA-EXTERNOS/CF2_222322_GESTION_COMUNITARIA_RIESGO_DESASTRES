function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5kWsHtpZxFp":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

