function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6evivN3SIxY":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

